;;; 70-neomutt.el --- NeoMuttt configurations. -*- lexical-binding: t -*-
;;; Commentary:
;;; Code:
;; (setq debug-on-error t)


(leaf *neomutt
  :doc "NeoMutt integration with emacsclient."
  :hook ((server-visit-hook . my-neomutt-setup)
         (server-done-hook  . my-neomutt-server-done))
  :bind (("C-x C-c" . server-edit))  ; same as C-x #
  :config
  (add-to-list 'auto-mode-alist '("/neomutt-" . neomutt-mail-mode))
  :preface
  (define-derived-mode neomutt-mail-mode text-mode "NeoMutt"
    "Major mode for editing NeoMutt compose buffers via emacsclient.")

  (defun my-neomutt-setup ()
    "Prepare a NeoMutt compose buffer."
    (when (and buffer-file-name
               (string-match-p "neomutt" buffer-file-name))
      (neomutt-mail-mode)))

  (defun my-neomutt-server-done ()
    "Run after `server-edit' (C-x C-c) finishes."
    (when (derived-mode-p 'neomutt-mail-mode)
      (when (bound-and-true-p darkroom-mode)
        (my-darkroom-out))
      (let ((buf (current-buffer))
            (frame (selected-frame)))
        (kill-buffer buf)
        (when (frame-live-p frame)
          (iconify-frame frame))))))


;; Local Variables:
;; byte-compile-warnings: (not free-vars unresolved)
;; End:
;;; 70-neomutt.el ends here
