;;; my-evil-cheat-sheet.el --- Evil keybinding cheat sheet -*- lexical-binding: t -*-
;;; Commentary:
;; Claude-recommended evil keybindings, tailored for this config.
;; Bound to ? in normal-state.
;;
;;; Code:

(add-to-list 'display-buffer-alist
             '("\\*evil-cheat\\*"
               (display-buffer-in-side-window)
               (side . right)
               (slot . 0)
               (window-width . 42)
               (window-parameters . ((no-delete-other-windows . t)
                                     (mode-line-format . none)))))

(defvar evil-cheat-mode-map
  (let ((map (make-sparse-keymap)))
    (keymap-set map "q" #'quit-window)
    map)
  "Keymap for evil-cheat buffer.")

(defun my-evil-cheat-sheet ()
  "Toggle evil keybindings cheat sheet in right sidebar.
? to open/close q: quit."
  (interactive)
  (if-let ((win (get-buffer-window "*evil-cheat*")))
      (delete-window win)
    (with-current-buffer (get-buffer-create "*evil-cheat*")
      (setq buffer-read-only nil)
      (erase-buffer)
      (insert "\
【move:移動】
  w b        単語単位 前進/後退
  e          次の単語末尾へ
  0 $        行頭/行末
  fx Fx      行内の文字xへ（F は逆方向）
  tx         文字xの直前へ
  { }        段落単位で移動
  %          対応する括弧へ

【edit:編集（normal-state のまま）】
  x          カーソル文字を削除
  X          カーソル前の文字を削除
  r          1文字だけ置換
  dd         行ごと削除（カット）
  D          行末まで削除
  yy         行全体をヤンク
  p P        カーソルの後/前にペースト
  J          次行を現在行に連結
  ~          大文字/小文字を切り替え
  u  C-r     undo / redo
  .          直前の編集を繰り返す

【operator + motion】
  dw diw daw 単語削除（各種）
  yw yiw     単語ヤンク
  2dd 3w     数字+コマンドで繰り返し
  ※ cw 等 c系は無効化済み

【visual-state（@ で開始）】
  @          文字選択モード開始
  _          行選択モード開始
  viw vi\"   単語/クォート内を選択
  va(        () ごと選択
  d y        削除/ヤンク
  u U        小文字化/大文字化
  PgUp/Dn    選択範囲 拡大/縮小

【normal-state に留まるコツ】
  r          1文字修正はこれで完結
  x          不要な1文字の削除
  dd→移動→p  行の移動
  diw→i→無変換  単語の置換
  J          改行を消して行を繋げる
  .          直前の編集を繰り返す
")
      (evil-emacs-state)
      (use-local-map evil-cheat-mode-map)
      (setq buffer-read-only t)
      (goto-char (point-min)))
   (select-window (display-buffer "*evil-cheat*"))))


(provide 'my-evil-cheat-sheet)
;;; my-evil-cheat-sheet.el ends here
