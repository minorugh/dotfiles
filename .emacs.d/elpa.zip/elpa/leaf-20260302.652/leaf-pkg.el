;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf" "20260302.652"
  "Simplify your init.el configuration, extended use-package."
  '((emacs "24.1"))
  :url "https://github.com/conao3/leaf.el"
  :commit "b49e68613b8efba89c702141f49ad9b4460a7204"
  :revdesc "b49e68613b8e"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
