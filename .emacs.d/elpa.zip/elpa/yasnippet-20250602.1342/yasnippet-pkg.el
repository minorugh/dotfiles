;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yasnippet" "20250602.1342"
  "Yet another snippet extension for Emacs."
  '((cl-lib "0.5")
    (emacs  "24.4"))
  :url "https://github.com/joaotavora/yasnippet"
  :commit "dd570a6b22364212fff9769cbf4376bdbd7a63c5"
  :revdesc "dd570a6b2236"
  :keywords '("convenience" "emulation")
  :authors '(("pluskid" . "pluskid@gmail.com")
             ("João Távora" . "joaotavora@gmail.com")
             ("Noam Postavsky" . "npostavs@gmail.com"))
  :maintainers '(("Noam Postavsky" . "npostavs@gmail.com")))
