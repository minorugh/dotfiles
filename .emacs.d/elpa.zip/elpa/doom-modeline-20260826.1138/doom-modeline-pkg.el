;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260826.1138"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "f35c9c9eb111c59377c4bad86497d38eff716df0"
  :revdesc "f35c9c9eb111"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
