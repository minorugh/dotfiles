;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-keywords" "20260516.827"
  "Additional leaf.el keywords for external packages."
  '((emacs "24.4")
    (leaf  "4.5.5"))
  :url "https://github.com/conao3/leaf-keywords.el"
  :commit "36efb8c94071c0fd98b6534866297f2238b78630"
  :revdesc "36efb8c94071"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
